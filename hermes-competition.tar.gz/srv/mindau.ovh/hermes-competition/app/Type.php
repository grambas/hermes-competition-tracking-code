<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Type
 *
 * @package App
 * @property text $desc
*/
class Type extends Model
{
    protected $fillable = ['desc'];
    
    
    
}
