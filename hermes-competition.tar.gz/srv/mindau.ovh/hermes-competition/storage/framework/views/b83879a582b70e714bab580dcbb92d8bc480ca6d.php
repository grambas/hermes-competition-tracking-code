<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Hermes Competition project by Mindaugas Milius</title>

     <!--  CSS -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/main.css')); ?>">

    </head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Home</a>
        <a class="navbar-brand" href="<?php echo e(route('track')); ?>">Track Package</a>
        <a class="navbar-brand" href="<?php echo e(route('simulation')); ?>">Simulation</a>
        <div class=" float-right"><span class="red"> Debug: </span><input id="debug" class="btn-danger" checked data-toggle="toggle" type="checkbox"></div>
        <a class="navbar-brand debug red float-right" href="">Demonstration</a>
      </div>
</nav>

<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>

<div class="container">
    <pre id="logger">
        <h1>console.log</h1>
    </pre>
</div>



    <!--  JS -->
    
    <script type="text/javascript" charset="UTF-8" src="<?php echo e(URL::asset('js/jquery.min.js')); ?>"></script>

    <!--  Google Maps Api -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB22CeN3MfdvEvsYelWXZXq4iTyLZSjerM"></script>
    <!--  bootstrap html framework  -->
    <script type="text/javascript" charset="UTF-8" src="<?php echo e(URL::asset('js/tether.min.js')); ?>"></script>
    <script type="text/javascript" charset="UTF-8" src="<?php echo e(URL::asset('js/bootstrap.min.js')); ?>"></script>

    <!--  Main JS -->
    <script src="<?php echo e(URL::asset('js/main.js')); ?>"></script>

</body>
</html>